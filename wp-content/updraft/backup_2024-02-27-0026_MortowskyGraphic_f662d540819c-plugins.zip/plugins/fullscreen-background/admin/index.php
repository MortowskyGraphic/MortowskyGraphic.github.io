<?php
/**
 * Silence is golden
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://www.enweby.com/
 * @since      1.0.0
 *
 * @package    Fullscreen_Background
 */

?>
<!-- Silence is golden. -->

